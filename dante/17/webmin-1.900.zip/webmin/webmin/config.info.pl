standard_url=URL listy modu��w standardowych,3,www.webmin.com
third_url=URL listy modu��w os�b trzecich,3,www.webmin.com
cron_mode=Pokazuj czasy aktualizacji jako,1,0-Prosty,1-Ustawienia czasu Crona
warn_days=Na ile dni przed wyga�ni�ciem has�a ostrzega� u�ytkownik�w?,0,5
