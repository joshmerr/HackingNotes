desc_pl=Pakiety oprogramowania
longdesc_pl=Zarz�dzaj pakietami oprogramowania w twoim systemie i instaluj nowe pakiety.
