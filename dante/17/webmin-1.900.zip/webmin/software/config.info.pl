package_system=System zarz�dzania pakietami,1,rpm-RPM,pkgadd-Solaris,hpux-HPUX,freebsd-FreeBSD,slackware-Slackware,debian-Debian
update_system=System aktualizacji pakietu,1,-Automatycznie,apt-APT,yum-YUM,rhn-Redhat Network,csw-Blastwave CSW,urpmi-URPMI,emerge-Emerge,ports-FreeBSD Ports,pkg-FreeBSD pkgng,pkgsrc-PKGsrc,*-Brak
apt_mode=Polecenie instalacji dla APT,1,0-apt&#45;get,1-aptitude
